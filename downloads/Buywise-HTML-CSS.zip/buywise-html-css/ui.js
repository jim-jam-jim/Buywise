/* Local display controls only. No authentication, purchases or data writes are simulated. */
(() => {
  let timer;
  function explain() {
    document.querySelector('.static-notice')?.remove();
    const notice = document.createElement('div');
    notice.className = 'toast static-notice';
    notice.setAttribute('role', 'status');
    notice.textContent = 'This action requires the full BUYWISE application. This ZIP preserves the interface.';
    const close = document.createElement('button');
    close.type = 'button'; close.setAttribute('aria-label', 'Dismiss notification'); close.textContent = '×';
    close.onclick = () => notice.remove(); notice.append(close); document.body.append(notice);
    clearTimeout(timer); timer = setTimeout(() => notice.remove(), 6500);
  }
  document.querySelector('.sidebar-collapse')?.addEventListener('click', () => {
    const collapsed = document.querySelector('.app-shell').classList.toggle('collapsed');
    document.querySelector('.sidebar-collapse').setAttribute('aria-label', collapsed ? 'Expand navigation' : 'Collapse navigation');
  });
  document.querySelector('.mobile-menu')?.addEventListener('click', () => document.querySelector('.sidebar')?.classList.add('mobile-open'));
  document.querySelector('.mobile-close')?.addEventListener('click', () => document.querySelector('.sidebar')?.classList.remove('mobile-open'));
  document.querySelector('[aria-label="Close dialog"]')?.addEventListener('click', () => document.querySelector('.modal-backdrop')?.remove());
  document.addEventListener('keydown', event => {if(event.key === 'Escape'){document.querySelector('.modal-backdrop')?.remove();document.querySelector('.sidebar')?.classList.remove('mobile-open');}});
  document.querySelector('.account-button')?.addEventListener('click', () => {location.href = 'login.html';});
  document.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => {location.href = button.dataset.page;}));
  document.querySelectorAll('form').forEach(form => form.addEventListener('submit', event => {
    event.preventDefault();
    if(form.classList.contains('global-search')){
      location.href = 'shop.html?q=' + encodeURIComponent(new FormData(form).get('q') || '');
    } else if(form.classList.contains('filter-bar')) filterProducts();
    else explain();
  }));
  function filterProducts(){
    const input=document.querySelector('[aria-label="Search catalogue"]');if(!input)return;
    const q=input.value.toLowerCase();
    const category=document.querySelector('[aria-label="Filter category"]')?.value||'';
    let shown=0;
    document.querySelectorAll('.product-card').forEach(card=>{
      const text=card.textContent.toLowerCase();
      const matches=text.includes(q)&&(!category||text.includes(category.toLowerCase()));
      card.hidden=!matches;if(matches)shown++;
    });
    const count=document.querySelector('.results-heading p strong');if(count)count.textContent=String(shown);
  }
  const search=document.querySelector('[aria-label="Search catalogue"]');
  if(search){search.value=new URLSearchParams(location.search).get('q')||search.value;search.addEventListener('input',filterProducts);filterProducts();}
  document.querySelector('[aria-label="Filter category"]')?.addEventListener('change',filterProducts);
  document.querySelectorAll('button').forEach(button=>{
    if(button.dataset.page||button.closest('.global-search')||button.matches('.sidebar-collapse,.mobile-menu,.mobile-close,.account-button,[aria-label="Close dialog"]'))return;
    if(button.type==='submit'&&button.closest('form'))return;
    button.addEventListener('click',event=>{event.preventDefault();explain();});
  });
})();
