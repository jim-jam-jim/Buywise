BUYWISE — HTML / CSS interface export

OPEN index.html in a browser to view the dashboard. No installation or internet connection is needed.

This export uses the actual rendered HTML, original production CSS, inline SVG icons and category illustrations from BUYWISE commit 511c23e. It is not a redesign. The existing responsive layouts and CSS theme definitions are preserved. Page links work locally.

Included:
- Dashboard, discovery catalogue and all 12 product detail pages
- Comparison, budgets, purchase rules and watchlist
- Completed decision receipt and pending purchase review
- History, insights and notifications
- Profile, privacy, integrations, onboarding and help
- Sign-in and registration screens
- Open-dialog examples for new budgets, rules and manual reviews
- styles.css: the application's production stylesheet
- icon.svg: the original application icon
- ui.js: small local navigation/menu controls and basic catalogue text/category filtering
- pages.json: list of exported HTML pages

These are static snapshots using an export-only example account and the application's explicitly labelled demo catalogue. No actual customer data, passwords, sessions, API tokens or database files are included. The temporary export account was deleted after generation.

The HTML and CSS preserve the interface. They cannot replace the Next.js server, PostgreSQL database, authentication, rule evaluation, live provider requests or persistent writes. Buttons requiring those services explain that the full application is needed; they do not pretend to save, log in, approve or delete anything. ui.js is optional for the visual layout, but required for its small menu/navigation helpers.

For the working full-stack product:
https://github.com/jim-jam-jim/Buywise

The source application is required to edit real account data and run purchase reviews. The sample balances, decisions and timestamps in this ZIP are display snapshots rather than live values.
